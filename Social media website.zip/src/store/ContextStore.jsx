


import { createContext, useEffect, useReducer, useState } from "react";

// Create the context
export const PostListData = createContext({
  postList: [],
  fetching: false,
  addPost: () => { },
  deletePost: () => { },
});




// Reducer function to manage post list state
const postListReducer = (currentPostList, action) => {
  let newPostList = currentPostList;

  if (action.type === "DELETE-POST") {
    newPostList = currentPostList.filter(post => post.id !== action.payload.postId);
  } else if (action.type === "ADD-POST") {
    newPostList = [action.payload, ...currentPostList];
  } else if (action.type === "ADD-Initial-POSTs") {
    newPostList = action.payload.posts;
  }

  // Save the new post list to local storage
  localStorage.setItem("postList", JSON.stringify(newPostList));
  return newPostList;
};

const PostListProvider = ({ children }) => {
  // Initialize state with data from local storage or an empty array
  const [postList, dispatchPostList] = useReducer(postListReducer, [], () => {
    const localData = localStorage.getItem("postList");
    return localData ? JSON.parse(localData) : [];
  });

  const [fetching, setFetching] = useState(false);

  const addPost = (post) => {
    dispatchPostList({
      type: "ADD-POST",
      payload: post,
    });
  };

  const addInitialPosts = (posts) => {
    dispatchPostList({
      type: "ADD-Initial-POSTs",
      payload: {
        posts,
      },
    });
  };

  const deletePost = (postId) => {
    dispatchPostList({
      type: "DELETE-POST",
      payload: {
        postId,
      },
    });
  };

  useEffect(() => {
    // Fetch initial posts if local storage is empty
    if (!localStorage.getItem("postList")) {
      setFetching(true);
      const controller = new AbortController();
      const signal = controller.signal;

      fetch('https://dummyjson.com/posts', { signal })
        .then(res => res.json())
        .then(data => {
          addInitialPosts(data.posts);
          setFetching(false);
        })
        .catch(() => setFetching(false));

      return () => {
        controller.abort();
      };
    }
  }, []);

  return (
    <PostListData.Provider value={{ postList, addPost, fetching, deletePost }}>
      {children}
    </PostListData.Provider>
  );
};

export default PostListProvider;
