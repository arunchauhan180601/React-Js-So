import "bootstrap/dist/css/bootstrap.min.css"
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import './App.css'
import Header from './components/Header'
import Footer from "./components/Footer"
import Sidebar from "./components/Sidebar"

import PostListProvider from "./store/ContextStore";
import { Outlet } from "react-router-dom";





function App() {





  return (
    <>

      <PostListProvider>
        <Header />
        <div className="main-container mt-5 d-flex">
          <Sidebar />

          <Outlet />

        </div>
        <Footer />
      </PostListProvider>


    </>
  )
}

export default App
