import React from 'react'

const WelcomeMessage = () => {
  return (
    <>
      <div className='welcomeMessage-flex-column'>
        <h2 className="fw-bold welcomeMessage">There are no Posts</h2>

      </div>
    </>
  )
}

export default WelcomeMessage