import { useContext, useRef } from "react";
import { PostListData } from "../store/ContextStore";





function Form() {


  const { addPost } = useContext(PostListData);


  const userIdElement = useRef();
  const postTitleElement = useRef();
  const postBodyElement = useRef();
  const reactionsElement = useRef();
  const tagsElement = useRef();



  const handleSubmit = (event) => {
    event.preventDefault();
    const userId = userIdElement.current.value;
    const postTitle = postTitleElement.current.value;
    const postBody = postBodyElement.current.value;
    const reactions = reactionsElement.current.value.split(",");
    const likes = parseInt(reactions[0], 10);
    const dislikes = parseInt(reactions[1], 10);
    const tags = tagsElement.current.value.split(",");

    userIdElement.current.value = "";
    postTitleElement.current.value = "";
    postBodyElement.current.value = "";
    reactionsElement.current.value = "";
    tagsElement.current.value = "";


    fetch('https://dummyjson.com/posts/add', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({

        title: postTitle,
        body: postBody,
        reactions: { likes, dislikes },
        userId: userId,
        tags: tags
      })
    })
      .then(res => res.json())
      .then(post => addPost(post));

    // addPost(userId, postTitle, postBody, { likes, dislikes }, tags)

  }




  return (
    <>
      <form className="form-main" onSubmit={handleSubmit}>
        <h1 className="create-post mb-5" >Create Post</h1>

        <div className="mb-3">
          <label htmlFor="userId" className="form-label"> Enter Your User Id</label>
          <input type="text" ref={userIdElement} className="form-control" id="userId" placeholder="Your User Id In Number " autoComplete="off" />

        </div>

        <div className="mb-3">
          <label htmlFor="title" className="form-label">Title</label>
          <input type="text" ref={postTitleElement} className="form-control" id="title" placeholder="How are you feeling Today?" autoComplete="off" />

        </div>

        <div className="mb-3">
          <label htmlFor="body" className="form-label">Post Content</label>
          <textarea type="text" ref={postBodyElement} rows="3" className="form-control" id="body" placeholder="Tell us more about it" />

        </div>

        <div className="mb-3">
          <label htmlFor="reactions" className="form-label"> Number Of Reactions (likes,dislikes)</label>
          <input type="text" ref={reactionsElement} className="form-control" id="reactions" placeholder="e.g., 10,2" autoComplete="off" />

        </div>

        <div className="mb-3">
          <label htmlFor="tags" className="form-label"> Enter Your Hashtags Here</label>
          <input type="text" ref={tagsElement} className="form-control" id="tags" placeholder=" plz Enter tags using comma" autoComplete="off" />

        </div>



        <button type="submit" className="btn btn-submit">Post</button>
      </form>
    </>
  )
}
export default Form;