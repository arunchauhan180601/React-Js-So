function Footer() {
  return (
    <>
      <div className="footer-main">
        <div className="container pb-1">
          <footer className="pt-3 pb-0 mb-4">
            <ul className="nav justify-content-center border-bottom pb-3 mb-3 footer-ul">
              <li className="nav-item"><a href="#" className="nav-link px-2 ">Home</a></li>
              <li className="nav-item"><a href="#" className="nav-link px-2 ">Features</a></li>
              <li className="nav-item"><a href="#" className="nav-link px-2 ">Pricing</a></li>
              <li className="nav-item"><a href="#" className="nav-link px-2 ">FAQs</a></li>
              <li className="nav-item"><a href="#" className="nav-link px-2 ">About</a></li>
            </ul>
            <p className="text-center ">© 2024 Company, Inc</p>
          </footer>
        </div>
      </div>
    </>
  )
}

export default Footer;