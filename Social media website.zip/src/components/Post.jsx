import { useContext } from "react";
import { MdDelete } from "react-icons/md";
import { PostListData } from "../store/ContextStore";

function Post({ post }) {

  const { deletePost } = useContext(PostListData);

  return (
    <>

      <div className="card">
        <div className="card-body">
          <h5 className="card-title">{post.title}</h5>
          <p className="card-text">{post.body}</p>

          {post.tags.map((tag, index) => {
            return <span className="badge bg-danger p-2 me-2 mt-1" key={index}>{tag}</span>
          })}

          <div className="alert alert-danger mt-3" role="alert">
            This Post has been Liked by {post.reactions.likes} and disliked by {post.reactions.dislikes} people.
          </div>

          <span className="position-absolute top-0 start-100 detele-icon translate-middle badge rounded-pill bg-danger"
            onClick={() => deletePost(post.id)}>
            <MdDelete />

          </span>

        </div>
      </div>

    </>
  )
}

export default Post;