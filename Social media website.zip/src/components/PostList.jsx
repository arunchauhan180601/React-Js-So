
import Post from './Post'
import { PostListData } from '../store/ContextStore'
import WelcomeMessage from './WelcomeMessage';
import LoadingSpinner from './LoadingSpinner';
import { useContext } from 'react';


const PostList = () => {

  const { postList, fetching } = useContext(PostListData);






  return (
    <>
      <div className="card-container mt-3">

        {fetching && <LoadingSpinner />}
        {!fetching && postList.length === 0 && <WelcomeMessage />}
        {!fetching && postList.map((post) => {
          return <Post post={post} key={post.id} />
        })}

      </div>
    </>
  )
}

export default PostList